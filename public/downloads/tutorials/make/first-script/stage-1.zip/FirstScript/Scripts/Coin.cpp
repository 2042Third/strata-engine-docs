// Coin: a script class. Once the scripts are built with it (Scripts > Build Scripts; New Script starts a build), attach
// it to an entity (Inspector > Add Component > Script, or the command script.add); Play rebuilds the scripts when they
// changed. Fields (ST_SCRIPT_FIELD) are set per entity in the Inspector and kept across hot reloads.
// Docs/Manual/Scripting.md in the Strata engine's folder describes the SDK, building, debugging and hot reload.

#include "StrataScript/StrataScript.h"

using namespace Strata;

class Coin : public Script
{
public:
	float Speed = 1.0f;

	// When the entity starts playing (its fields hold the scene's values by now).
	void OnCreate() override
	{
	}

	// Every frame; deltaTime is the frame's game time in seconds.
	void OnUpdate([[maybe_unused]] float deltaTime) override
	{
	}
};

ST_SCRIPT_CLASS(Coin)
{
	ST_SCRIPT_FIELD(Speed);
}
